package modelo2;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class MedicoDAO {
	
	 public Medico obtenerMedicoPorId(int id) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Medico medico = null;

	        try {
	            Query<Medico> query = session.createQuery("FROM Medico WHERE id = :id", Medico.class);
	            query.setParameter("id", id);
	            medico = query.uniqueResult();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }

	        return medico;
	    }

    public void crearMedico(Medico medico) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            session.save(medico);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void eliminarMedico(Medico medico) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            session.delete(medico);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public List<Medico> obtenerTodosLosMedicos() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Medico> medicos = new ArrayList<>();

        try {
            Query<Medico> query = session.createQuery("FROM medicos", Medico.class);
            medicos = query.list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }

        return medicos;
    }

    public void modificarMedico(Medico medico) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            session.update(medico);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}