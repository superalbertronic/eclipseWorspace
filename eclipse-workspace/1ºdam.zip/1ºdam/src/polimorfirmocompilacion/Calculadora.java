package polimorfirmocompilacion;

public class Calculadora {
    public static int sumar(int a, int b) {
        return a + b;
    }
    
    public static int sumar(int a, int b, int c) {
        return a + b + c;
    }
    
    public static double sumar(double a, double b) {
        return a + b;
    }
}


