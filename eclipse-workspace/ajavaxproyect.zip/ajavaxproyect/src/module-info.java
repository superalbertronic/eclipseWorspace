module ajavaxproyect {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.base;
	
	opens application to javafx.graphics, javafx.fxml;
	opens Ejercicio1 to javafx.graphics, javafx.fxml;
	opens Ejercicio2 to javafx.graphics, javafx.fxml;
	opens Ejercicio3 to javafx.graphics, javafx.fxml;
	opens Ejercicio4 to javafx.graphics, javafx.fxml;
	opens Ejercicio5 to javafx.graphics, javafx.fxml;
	opens Ejercicio6 to javafx.graphics, javafx.fxml;
	opens Ejercicio7 to javafx.graphics, javafx.fxml;
	opens Ejercicio8 to javafx.graphics, javafx.fxml;
	opens Ejercicio9 to javafx.graphics, javafx.fxml;
	opens Ejercicio10Hilo to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio11 to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio12 to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio13Controles to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio14Controles to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio15Controles to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio16Controles to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio17menu to javafx.graphics, javafx.fxml;
	opens Tema6Ejercicio18Calculadora to javafx.graphics, javafx.fxml;
	opens tema6Ejercicio19ProgressSlider to javafx.graphics, javafx.fxml;
}
