package Abstractainterface4;

public interface ProductoInterfaz {

	void MostrarInformacion();
	
}

