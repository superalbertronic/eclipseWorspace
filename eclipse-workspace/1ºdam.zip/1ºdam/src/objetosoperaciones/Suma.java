package objetosoperaciones;

public class Suma extends Operacion{
    void operar() {
        resultado=valor1+valor2;
    }
}
