package interfaces;

public class OperacionesMain {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		Calculadora miCalculadora = new Calculadora();
	    System.out.println("la suma es "+ miCalculadora.sumar(5, 3));
	    System.out.println("la resta es "+miCalculadora.restar(5, 3));
	}

}
