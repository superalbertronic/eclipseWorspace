package rentasimple;

public class RentaSimple {
	public static void main(String arg[]) { 
	double capital = 500.0;
	double inter�s =6.25;
	double rentaSimple;
	rentaSimple=capital*inter�s/100 ;
	capital +=rentaSimple;
	System.out.println("El capital es "+capital);
	System.out.println("El empleado es "+rentaSimple);
	}
}