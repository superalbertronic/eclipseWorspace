package patronmethod;

public class Fisica implements Asignatura {
    public String getNombre() {
        return "Física";
    }
    
    public int getCodigo() {
        return 2;
    }
}


