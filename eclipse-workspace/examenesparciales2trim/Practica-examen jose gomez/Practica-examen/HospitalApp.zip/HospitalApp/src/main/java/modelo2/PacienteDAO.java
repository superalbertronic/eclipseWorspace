package modelo2;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
	
	 public void crearPaciente(Paciente paciente) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();
	            session.save(paciente);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }

	 public void eliminarPaciente(Paciente paciente) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();
	            session.delete(paciente);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }
	 
	 
	 public List<Paciente> obtenerTodosLosPacientes() {
		    Session session = HibernateUtil.getSessionFactory().openSession();
		    List<Paciente> pacientes = new ArrayList<>();

		    try {
		        Query<Paciente> query = session.createQuery("FROM Paciente", Paciente.class);
		        pacientes = query.list();
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        session.close();
		    }

		    return pacientes;
		}

	    public void modificarPaciente(Paciente paciente) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();
	            session.update(paciente);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }
	    
	    public Paciente obtenerPacientePorId(int id) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Paciente paciente = null;

	        try {
	            Query<Paciente> query = session.createQuery("FROM Paciente WHERE id = :id", Paciente.class);
	            query.setParameter("id", id);
	            paciente = query.uniqueResult();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }

	        return paciente;
	    }
	
	
}



