package patronmethod;


public interface AsignaturaFactory {
    public Asignatura crearAsignatura
    (int codigo);
}



