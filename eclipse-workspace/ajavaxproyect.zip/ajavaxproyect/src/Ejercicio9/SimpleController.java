package Ejercicio9;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
public class SimpleController {
  

    // Puedes agregar métodos y lógica adicional aquí según tus necesidades
}
