package arralistabstractinterface.copia;

public interface Tablet {
    public int getTamanoPantalla();
    public boolean Wifi();
}

