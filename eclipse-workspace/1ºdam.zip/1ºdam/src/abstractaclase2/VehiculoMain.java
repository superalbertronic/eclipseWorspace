package abstractaclase2;

public class VehiculoMain {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		Coche coche1=new Coche(" Seat", "Rojo");
		coche1.MostrarDatos();
		
		
		
	}

}
