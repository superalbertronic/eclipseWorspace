package arralistabstractinterface.copia;

public interface Portatil {
    public int getTamanoPantalla();
}