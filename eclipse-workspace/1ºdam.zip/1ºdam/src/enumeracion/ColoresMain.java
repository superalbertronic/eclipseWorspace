package enumeracion;

public class ColoresMain {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		Colores micolor= Colores.Azul;
		Colores micolor1=Colores.Rojo;
		System.out.println("mi color favorito es "+micolor);
		System.out.println("tu color favorito es "+micolor1);
	}

}
