package arrays;
import java.util.Arrays;

public class ArrayIntString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
