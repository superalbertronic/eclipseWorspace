package abstractavehiculos;

public abstract class Vehiculo {
	String color;
	  int ruedas;
	  String modelo;

	  abstract void acelerar();

	  abstract void frenar();
	}


