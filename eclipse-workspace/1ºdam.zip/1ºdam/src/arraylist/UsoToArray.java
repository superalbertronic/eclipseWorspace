package arraylist;

import java.util.ArrayList;

public class UsoToArray {
    public static void main(String[] args) {
        // Creamos una lista de números enteros
        ArrayList<Integer> numeros = new ArrayList<Integer>();
        numeros.add(1);
        numeros.add(2);
        numeros.add(3);
        numeros.add(4);
        numeros.add(5);
        
        // Convertimos la lista en un array
        Integer[] arrayNumeros = numeros.toArray(new Integer[numeros.size()]);
        
        // Imprimimos el contenido del array
        for (Integer numero : arrayNumeros) {
            System.out.println(numero);
        }
    }
}