package polimorfirmoejecucion2;

public class Figura {
    public double calcularArea() {
        return 0.0;
    }

}
