package patronmethod;

public interface Asignatura {
    public String getNombre();
    public int getCodigo();
}



