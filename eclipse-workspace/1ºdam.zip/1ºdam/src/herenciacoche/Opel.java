package cochesherencia;

public class Opel extends Vehiculo {
	public Opel(String color) {
		this.marca= "Opel";
		this.modelo="Corsa";
		this.motor="General motos";
		this.precio=12000.100;
		this.color=color;
		
	}
	

}
