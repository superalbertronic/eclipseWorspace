package calculadora;

public interface Suma {

}