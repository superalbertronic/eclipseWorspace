package modelo2;

import java.util.List;
import java.util.Scanner;

public class HospitalApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("------ Menú ------");
            System.out.println("1. Gestionar pacientes");
            System.out.println("2. Gestionar médicos");
            System.out.println("3. Gestionar citas");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    gestionarPacientes();
                    break;
                case 2:
                    gestionarMedicos();
                    break;
                case 3:
                    gestionarCitas();
                    break;
            }
        } while (opcion != 4);
    }

    private static void gestionarPacientes() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        PacienteDAO pacienteDAO = new PacienteDAO();

        do {
            System.out.println("------ Menú Pacientes ------");
            System.out.println("1. Insertar paciente");
            System.out.println("2. Actualizar paciente");
            System.out.println("3. Mostrar lista de pacientes");
            System.out.println("4. Eliminar paciente");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
            case 1:
                // Lógica para insertar paciente
                System.out.println("Ingrese el nombre del paciente:");
                String nombrePaciente = scanner.next();
                System.out.println("Ingrese los apellidos del paciente:");
                String apellidosPaciente = scanner.next();
                System.out.println("Ingrese la ciudad del paciente:");
                String ciudadPaciente = scanner.next();
                System.out.println("Ingrese la dirección del paciente:");
                String direccionPaciente = scanner.next();
                System.out.println("Ingrese el teléfono del paciente:");
                String telefonoPaciente = scanner.next();
                System.out.println("Ingrese la edad del paciente:");
                int edadPaciente = scanner.nextInt();
                System.out.println("Ingrese el historial del paciente:");
                String historialPaciente = scanner.next();

                Paciente nuevoPaciente = new Paciente();
                nuevoPaciente.setNombre(nombrePaciente);
                nuevoPaciente.setApellidos(apellidosPaciente);
                nuevoPaciente.setCiudad(ciudadPaciente);
                nuevoPaciente.setDireccion(direccionPaciente);
                nuevoPaciente.setTelefono(telefonoPaciente);
                nuevoPaciente.setEdad(edadPaciente);
                nuevoPaciente.setHistorial(historialPaciente);
                
                pacienteDAO.crearPaciente(nuevoPaciente);

                System.out.println("¡Paciente agregado exitosamente!");
                break;
            case 2:
                // Lógica para actualizar paciente
                System.out.println("Ingrese el ID del paciente a actualizar:");
                int idPacienteActualizar = scanner.nextInt();

                Paciente pacienteExistente = pacienteDAO.obtenerPacientePorId(idPacienteActualizar);

                if (pacienteExistente != null) {
                    System.out.println("Ingrese el nuevo nombre del paciente:");
                    String nuevoNombre = scanner.next();
                    System.out.println("Ingrese los nuevos apellidos del paciente:");
                    String nuevosApellidos = scanner.next();
                    System.out.println("Ingrese la nueva ciudad del paciente:");
                    String nuevaCiudad = scanner.next();
                    System.out.println("Ingrese la nueva dirección del paciente:");
                    String nuevaDireccion = scanner.next();
                    System.out.println("Ingrese el nuevo teléfono del paciente:");
                    String nuevoTelefono = scanner.next();
                    System.out.println("Ingrese la nueva edad del paciente:");
                    int nuevaEdad = scanner.nextInt();
                    System.out.println("Ingrese el nuevo historial del paciente:");
                    String nuevoHistorial = scanner.next();

                    // Actualiza los campos del paciente existente
                    pacienteExistente.setNombre(nuevoNombre);
                    pacienteExistente.setApellidos(nuevosApellidos);
                    pacienteExistente.setCiudad(nuevaCiudad);
                    pacienteExistente.setDireccion(nuevaDireccion);
                    pacienteExistente.setTelefono(nuevoTelefono);
                    pacienteExistente.setEdad(nuevaEdad);
                    pacienteExistente.setHistorial(nuevoHistorial);

                    // Llama al método para actualizar en la base de datos
                    pacienteDAO.modificarPaciente(pacienteExistente);

                    System.out.println("¡Paciente actualizado exitosamente!");
                } else {
                    System.out.println("No se encontró un paciente con el ID proporcionado.");
                }
                break;
                case 3:
                    List<Paciente> pacientes = pacienteDAO.obtenerTodosLosPacientes();
                    for (Paciente paciente : pacientes) {
                        System.out.println(paciente.getId() + ". " + paciente.getNombre() + " " + paciente.getApellidos());
                    }
                    break;
                case 4:
                    // Lógica para eliminar paciente
                    System.out.println("Ingrese el ID del paciente a eliminar:");
                    int idPacienteEliminar = scanner.nextInt();

                    Paciente pacienteEliminar = pacienteDAO.obtenerPacientePorId(idPacienteEliminar);

                    if (pacienteEliminar != null) {
                        // Llama al método para eliminar en la base de datos
                        pacienteDAO.eliminarPaciente(pacienteEliminar);

                        System.out.println("¡Paciente eliminado exitosamente!");
                    } else {
                        System.out.println("No se encontró un paciente con el ID proporcionado.");
                    }
                    break;
            }
        } while (opcion != 5);
    }

    private static void gestionarMedicos() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        MedicoDAO medicoDAO = new MedicoDAO();

        do {
            System.out.println("------ Menú Médicos ------");
            System.out.println("1. Insertar médico");
            System.out.println("2. Actualizar médico");
            System.out.println("3. Mostrar lista de médicos");
            System.out.println("4. Eliminar médico");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
            case 1:
                // Lógica para insertar médico
                System.out.println("Ingrese el nombre del médico:");
                String nombre = scanner.next();
                System.out.println("Ingrese los apellidos del médico:");
                String apellidos = scanner.next();
                System.out.println("Ingrese la especialidad del médico:");
                String especialidad = scanner.next();

                Medico nuevoMedico = new Medico(nombre, apellidos, especialidad);
                medicoDAO.crearMedico(nuevoMedico);

                System.out.println("¡Médico agregado exitosamente!");
                break;
            case 2:
                // Lógica para actualizar médico
                System.out.println("Ingrese el ID del médico a actualizar:");
                int idMedicoActualizar = scanner.nextInt();

                Medico medicoExistente = medicoDAO.obtenerMedicoPorId(idMedicoActualizar);

                if (medicoExistente != null) {
                    System.out.println("Ingrese el nuevo nombre del médico:");
                    String nuevoNombre = scanner.next();
                    System.out.println("Ingrese los nuevos apellidos del médico:");
                    String nuevosApellidos = scanner.next();
                    System.out.println("Ingrese la nueva especialidad del médico:");
                    String nuevaEspecialidad = scanner.next();

                    // Actualiza los campos del médico existente
                    medicoExistente.setNombre(nuevoNombre);
                    medicoExistente.setApellidos(nuevosApellidos);
                    medicoExistente.setEspecialidad(nuevaEspecialidad);

                    // Llama al método para actualizar en la base de datos
                    medicoDAO.modificarMedico(medicoExistente);

                    System.out.println("¡Médico actualizado exitosamente!");
                } else {
                    System.out.println("No se encontró un médico con el ID proporcionado.");
                }
                break;
                case 3:
                    List<Medico> medicos = medicoDAO.obtenerTodosLosMedicos();
                    for (Medico medico : medicos) {
                        System.out.println(medico.getId() + ". " + medico.getNombre() + " " + medico.getApellidos());
                    }
                    break;
                case 4:
                    // Lógica para eliminar médico
                    System.out.println("Ingrese el ID del médico a eliminar:");
                    int idMedicoEliminar = scanner.nextInt();

                    Medico medicoEliminar = medicoDAO.obtenerMedicoPorId(idMedicoEliminar);

                    if (medicoEliminar != null) {
                       
                        medicoDAO.eliminarMedico(medicoEliminar);

                        System.out.println("¡Médico eliminado exitosamente!");
                    } else {
                        System.out.println("No se encontró un médico con el ID proporcionado.");
                    }
                    break;
            }
        } while (opcion != 5);
    }

    private static void gestionarCitas() {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        CitaDAO citaDAO = new CitaDAO();

        do {
            System.out.println("------ Menú Citas ------");
            System.out.println("1. Agendar cita");
            System.out.println("2. Mostrar todas las citas");
            System.out.println("3. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            PacienteDAO pacienteDAO = new PacienteDAO();
            MedicoDAO medicoDAO = new MedicoDAO();
            switch (opcion) {
            case 1:
                // Lógica para agendar cita
                System.out.println("Ingrese el ID del paciente:");
                int idPaciente = scanner.nextInt();
                System.out.println("Ingrese el ID del médico:");
                int idMedico = scanner.nextInt();
                System.out.println("Ingrese la fecha de la cita (formato: YYYY-MM-DD):");
                String fechaCita = scanner.next();
                System.out.println("Ingrese la hora de la cita (formato: HH:mm):");
                String horaCita = scanner.next();

                Paciente paciente = pacienteDAO.obtenerPacientePorId(idPaciente);
                Medico medico = medicoDAO.obtenerMedicoPorId(idMedico);

                if (paciente != null && medico != null) {
                    Cita nuevaCita = new Cita();
                    nuevaCita.setPaciente(paciente);
                    nuevaCita.setMedico(medico);
                    nuevaCita.setFecha(fechaCita);
                    nuevaCita.setHora(horaCita);

                    citaDAO.crearCita(nuevaCita);

                    System.out.println("¡Cita agendada exitosamente!");
                } else {
                    System.out.println("No se encontró un paciente o médico con el ID proporcionado.");
                }
                break;
                case 2:
                    List<Cita> citas = citaDAO.obtenerTodasLasCitas();
                    for (Cita cita : citas) {
                        System.out.println("ID: " + cita.getId());
                        System.out.println("Paciente: " + cita.getPaciente().getNombre() + " " + cita.getPaciente().getApellidos());
                        System.out.println("Médico: " + cita.getMedico().getNombre() + " " + cita.getMedico().getApellidos());
                        System.out.println("Fecha: " + cita.getFecha());
                        System.out.println("Hora: " + cita.getHora());
                        System.out.println("------------------------");
                    }
                    break;
            }
        } while (opcion != 3);
    }
}
