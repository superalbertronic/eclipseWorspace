package interface2;

public class OperacionesMain {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		Calculadora calculadora=new Calculadora();
		System.out.println(" la suma es " +calculadora.sumar(20, 10));
		System.out.println(" la resta es " +calculadora.restar(30, 10));
		System.out.println(" la multi es " +calculadora.multi(20, 10));
		System.out.println(" la  division es  " +calculadora.division(30, 10));
		
		
	}

}
