package objetos;

/**
 * Libro.java
 * Definición de la clase Libro
 * @author Alberto Ruiz
 */
public class Libro {
	// atributos
	protected String isbn;
	protected String titulo;
	protected String autor;
	protected  int numeroDePaginas;
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getNumeroDePaginas() {
		return numeroDePaginas;
	}
	public void setNumeroDePaginas(int numeroDePaginas) {
		this.numeroDePaginas = numeroDePaginas;
	}

}
