package patronmethod;

public class Quimica implements Asignatura {
    public String getNombre() {
        return "Química";
    }
    
    public int getCodigo() {
        return 4;
    }
}

