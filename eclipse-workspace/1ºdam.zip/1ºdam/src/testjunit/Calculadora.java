package testjunit;

public class Calculadora{
	//operación suma
    public static int suma(int a, int b) {
        return a + b;  }
  //operación resta
    public static int resta(int a, int b) {
        return a - b; }
  //operación multiplicación
    public static int multi(int a, int b) {
        return a * b;    }
  //operación división
    public static int division(int a, int b) {
        
        return a / b;
    }
}
