package arralistabstractinterface;

public interface Portatil {
    public int getTamanoPantalla();
}