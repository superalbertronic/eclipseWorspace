package abstractainterface;



class Librointerface implements Productointerface {
    
	private String nombre;
	private String autor;
	private Double precio;
	private String descripcion;
    
    
    public Librointerface(String nombre, String descripcion, double precio, String autor) {
        
       
    }
    
    @Override
    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Descripcion: " + descripcion);
        System.out.println("Precio: " + precio);
        System.out.println("Autor: " + autor);
    }
}

