package polimorfismoejecucion;

public class Perro  extends Animal{
    public void hacerSonido() {
        System.out.println("El perro ladra");
    }

	
	
}
