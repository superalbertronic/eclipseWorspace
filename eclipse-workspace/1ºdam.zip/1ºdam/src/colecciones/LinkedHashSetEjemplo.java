package colecciones;
import java.util.LinkedHashSet;


public class LinkedHashSetEjemplo {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add("superalbertron");
        linkedHashSet.add("javitron");
        linkedHashSet.add("pablitron");
        System.out.println(linkedHashSet);

	}

}
