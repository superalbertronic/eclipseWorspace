package abstractaATS;

public class AnimalHerviboro extends animal{
    @Override
    public void alimentarse() {
        System.out.println("El animal herbívoro se alimenta de hierba");

    }
}
