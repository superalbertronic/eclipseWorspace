package abstracta;

public class ArrayClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
