package refactorizar;

public class VariablesAutoexplicativas {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		//ejemplo primero sin refactorizar
		int x=1;
		int y=2;
		System.out.println("la suma es "+(x+y));
		//Factorizando
		int numero1=1;
		int numero2=2;
		int suma=numero1+numero2;
		System.out.println("la suma es "+suma);
		
	}

}
