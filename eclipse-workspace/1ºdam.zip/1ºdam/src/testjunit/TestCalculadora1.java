package testjunit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCalculadora1 {

	@Test
	void testSuma() {
		fail("No implementado aun");
	}

	@Test
	void testResta() {
		fail("No implementado aun");
	}

}
