package abstractaATS;

public abstract class SerVivo {
  /* tenemos que tener en cuenta que si creamos un método con abstract la clase tb tendrá
  que ser abstract
   */
    public abstract void alimentarse();
}
