package abstractaclase;

public class VehiculoMain {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente
		Coche coche1=new Coche("Seat","verde");
		coche1.mostrardatos();
			
		
	}

}
