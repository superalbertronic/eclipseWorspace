package arralistabstractinterface;

public interface Movil {
    public int getTamanoPantalla();
    public String getOperador();
}
