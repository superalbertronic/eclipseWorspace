package enumeracion;

public enum Colores {
	Rojo, Verde, Azul, Amarillo
}
