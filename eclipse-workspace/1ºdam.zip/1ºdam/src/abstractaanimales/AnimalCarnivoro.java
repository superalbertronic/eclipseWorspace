package abstractaATS;

public class AnimalCarnivoro extends animal{
    @Override
    public void alimentarse(){

    }
}
