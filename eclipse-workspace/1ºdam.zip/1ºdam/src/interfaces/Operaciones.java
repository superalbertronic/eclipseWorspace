package interfaces;

public interface Operaciones {
      int sumar(int a, int b);
	  int restar(int a, int b);
}

