package carpeta1dam;

public class ArrayLaura { 

public static void main(String[] args) {   
String[][] n = {{"Programación ","10"},{"Lenguaje de marcas ","8"},{"Base de datos ","9"}};                  
int fila, columna;
       
      
for(fila = 0; fila < 3; fila++) {
   
for(columna = 0; columna < 2; columna++) { 
System.out.print(n[fila][columna]);
    
 }       
System.out.println();
  
 }
  
 }

  
 }