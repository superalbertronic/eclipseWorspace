package patronmethod;

public class Matematicas implements Asignatura {
    public String getNombre() {
        return "Matemáticas";
    }
    
    public int getCodigo() {
        return 1;
    }
}

