package polimorfismoejecucion;

public class Gato extends Animal {
	public void hacerSonido() {
        System.out.println("El gato maulla");
    }

	
	
}
