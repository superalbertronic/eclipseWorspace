package Operacion;

public class Suma extends Operacion{
    void operar() {
        resultado=valor1+valor2;
    }
}

