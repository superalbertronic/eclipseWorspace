package arralistabstractinterface;

public interface Tablet {
    public int getTamanoPantalla();
    public boolean Wifi();
}

