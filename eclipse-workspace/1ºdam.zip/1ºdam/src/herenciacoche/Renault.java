package cochesherencia;

public class Renault extends Vehiculo {
	public Renault (String color) {
		this.marca= "Renault";
		this.modelo="laguna";
		this.motor="Renault";
		this.precio=20000.300;
		this.color=color;
		
	}
	

}