package interfaces;

public class Calculadora implements Operaciones{

		
	@Override
	public int sumar(int a, int b) {
		// TODO Esbozo de método generado automáticamente
		return a+b;
	}

	@Override
	public int restar(int a, int b) {
		// TODO Esbozo de método generado automáticamente
		return a-b;
	}

}
