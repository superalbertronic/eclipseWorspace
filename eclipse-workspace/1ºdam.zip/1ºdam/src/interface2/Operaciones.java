package interface2;

public interface Operaciones {
	int sumar(int a, int b);
	int restar (int a, int b);
	int multi (int a, int b);
	int divi (int a, int b);
}
