package cochesherencia;

public class Vehiculoprincipal {

	public static void main(String[] args) {
		Seat S=new Seat("celeste");
		Opel O=new Opel("Azul metalizado");
		Renault R=new Renault("Verde");
		System.out.println(S);
		System.out.println(O);
		System.out.println(R);
		
	}

}
