package objetosoperaciones;

public class Resta extends Operacion {
    void operar(){
        resultado=valor1-valor2;
    }
}

