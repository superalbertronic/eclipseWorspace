package colecciones;
import java.util.TreeSet;

public class TreeSetEjemplo {

    public static void main(String[] args) {
    	TreeSet<String> treeSett = new TreeSet<>();
    	treeSett.add("superalbertron");
    	treeSett.add("javitron");
    	treeSett.add("pablitron");
        System.out.println(treeSett);
    }
}

