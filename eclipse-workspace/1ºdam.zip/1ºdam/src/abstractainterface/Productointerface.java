package abstractainterface;



interface Productointerface {
    
    void mostrarInformacion();
   
}
