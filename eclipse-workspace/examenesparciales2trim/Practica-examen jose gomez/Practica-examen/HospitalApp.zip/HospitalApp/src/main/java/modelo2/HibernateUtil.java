package modelo2;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            // Crear la SessionFactory desde hibernate.cfg.xml
        	return new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

            // Asegúrate de especificar la ruta correcta al archivo hibernate.cfg.xml
        } catch (Throwable ex) {
            // Manejar errores de inicialización
            System.err.println("Error al inicializar la SessionFactory: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        // Cierre limpio de la SessionFactory
        getSessionFactory().close();
    }
}
