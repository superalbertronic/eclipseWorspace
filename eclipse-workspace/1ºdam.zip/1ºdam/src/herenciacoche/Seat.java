package cochesherencia;

public class Seat extends Vehiculo {
	public Seat(String color) {
		this.marca= "Seat";
		this.modelo="Ibiza";
		this.motor="wolswagen";
		this.precio=12000.9;
		this.color=color;
		
	}

	
	

}
