package polimorfismoejecucion;

public class Animal {
    public void hacerSonido() {
        System.out.println("El animal hace un sonido");
    }

}
