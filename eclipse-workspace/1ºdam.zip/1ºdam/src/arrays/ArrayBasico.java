package arrays;

public class ArrayBasico {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

	}

}
