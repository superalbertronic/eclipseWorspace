package arrays;

public class Array4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int	matriz[][]=new int	[3] [];
		matriz[0]=new int[3];
		matriz[1]=new int[4];
		matriz[2]=new int[2];
		matriz[1][0] = 123;
		System.out.println(matriz[1][0]);
	}

}
