package refactorizar;

interface prueba1 {

	String getMarca();

	String toString();

}