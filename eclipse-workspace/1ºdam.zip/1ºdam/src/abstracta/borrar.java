package abstracta;

import java.util.TreeSet;

public class borrar {

     public static void main(String[] args) {

        TreeSet<String> treeSet = new TreeSet<>();

        treeSet.add("Susana");

        treeSet.add("Javier");

        treeSet.add("Pedro");

        System.out.println(treeSet);

    }

}
