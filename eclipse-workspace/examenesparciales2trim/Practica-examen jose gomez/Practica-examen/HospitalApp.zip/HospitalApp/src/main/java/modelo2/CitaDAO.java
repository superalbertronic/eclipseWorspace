package modelo2;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class CitaDAO {
	 public void crearCita(Cita cita) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();
	            session.save(cita);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }

	 public void eliminarCita(Cita cita) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();
	            session.delete(cita);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }
	 
	 
	 public List<Cita> obtenerTodasLasCitas() {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        List<Cita> citas = new ArrayList<>();

	        try {
	        	  Query<Cita>query = session.createQuery("FROM citas", Cita.class);
	        	  
	            citas = query.list();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }

	        return citas;
	    }

	    public void modificarCita(Cita cita) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;

	        try {
	            transaction = session.beginTransaction();
	            session.update(cita);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }
}
