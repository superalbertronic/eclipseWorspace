package abstractaATS;

public abstract class animal extends SerVivo {

}
